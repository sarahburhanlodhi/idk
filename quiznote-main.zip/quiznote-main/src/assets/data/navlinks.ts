export const navlinks = [
  {
    name: "Changelog",
    url: "https://github.com/Evavic44/fun-notes",
  },
];
