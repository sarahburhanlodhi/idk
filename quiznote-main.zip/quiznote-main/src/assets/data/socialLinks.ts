import { GithubIcon } from "@/components/icons";

export const socialLinks = [
  {
    id: "GitHub",
    url: "https://github.com/Evavic44/fun-notes",
    icon: GithubIcon,
  },
];
